from django.contrib import admin

# from mainapp.models import Contacts, CategoryProduct, ScaleProduct, MarkProduct, ManufacturerProduct, ProductionProduct, MaterialProduct, Product
from mainapp.models import Contacts, CategoryProduct, ScaleProduct, MarkProduct
from mainapp.models import ManufacturerProduct, ProductionProduct, MaterialProduct, Product
# Register your models here.

admin.site.register(Contacts)
admin.site.register(CategoryProduct)
admin.site.register(ScaleProduct)
admin.site.register(MarkProduct)
admin.site.register(ManufacturerProduct)
admin.site.register(ProductionProduct)
admin.site.register(MaterialProduct)
admin.site.register(Product)