from django.db import models


class Contacts(models.Model):
    city = models.CharField(max_length=32, verbose_name='город')
    phone = models.CharField(max_length=32, verbose_name='телефон')
    email = models.CharField(max_length=128, verbose_name='email')
    street = models.CharField(max_length=128, verbose_name='улица')
    address = models.CharField(max_length=128, verbose_name='адрес')
    constructor = models.CharField(max_length=128, verbose_name='конструктор карты')

    def __str__(self):
        return f'{self.city}, {self.street}'


class CategoryProduct(models.Model):
    name = models.CharField(max_length=32,unique=True, verbose_name='Название категории')
    description = models.TextField(blank=True, verbose_name='Описание категории')
    is_active = models.BooleanField(verbose_name='активна', default=True)

    def __str__(self):
        return self.name

class ScaleProduct(models.Model):
    name = models.CharField(max_length=32,unique=True, verbose_name='Масштаб модели')
    description = models.TextField(blank=True, verbose_name='Описание')

    def __str__(self):
        return self.name

class MarkProduct(models.Model):
    name = models.CharField(max_length=32,unique=True, verbose_name='Марка модели')
    description = models.TextField(blank=True, verbose_name='Описание')

    def __str__(self):
        return self.name
    
class ManufacturerProduct(models.Model):
    name = models.CharField(max_length=32,unique=True, verbose_name='Производитель')
    description = models.TextField(blank=True, verbose_name='Описание')

    def __str__(self):
        return self.name

class ProductionProduct(models.Model):
    name = models.CharField(max_length=32,unique=True, verbose_name='Производство')
    description = models.TextField(blank=True, verbose_name='Описание')

    def __str__(self):
        return self.name

class MaterialProduct(models.Model):
    name = models.CharField(max_length=32,unique=True, verbose_name='Материал модели')
    description = models.TextField(blank=True, verbose_name='Описание')

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=64, verbose_name='Название модели')
    shortdesc = models.CharField(max_length=128, verbose_name='Кратое описание', blank=True)
    description = models.TextField(verbose_name='Подробное описание', blank=True)
    vendorcode = models.CharField(max_length=32, verbose_name='Артикул', blank=True)
    category =models.ForeignKey(CategoryProduct, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='products_images', blank=True)
    quantity = models.PositiveIntegerField(verbose_name='количество', default=0)
    price = models.DecimalField(verbose_name='цена', max_digits=10, decimal_places=2, default=0)
    scale = models.ForeignKey(ScaleProduct, on_delete=models.CASCADE)
    mark = models.ForeignKey(MarkProduct, on_delete=models.CASCADE)
    manufacturer = models.ForeignKey(ManufacturerProduct, on_delete=models.CASCADE)
    production = models.ForeignKey(ProductionProduct, on_delete=models.CASCADE)
    material = models.ForeignKey(MaterialProduct, on_delete=models.CASCADE)
    is_active = models.BooleanField(verbose_name='активна', default=True)

    def __str__(self):
        return self.name
    
