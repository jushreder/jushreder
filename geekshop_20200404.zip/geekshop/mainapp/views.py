from django.shortcuts import render, HttpResponseRedirect, get_object_or_404
from mainapp.models import Contacts, CategoryProduct, Product
from django.urls import reverse

import random, os
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def index(request):
    context ={
        'title': 'главная'
    }
    return render(request, 'mainapp/index.html', context)


def contact(request):
    locations = Contacts.objects.all()
    context ={
        'title' : 'контакты',
        'locations' : locations
    }
    return render(request, 'mainapp/contact.html', context)


def products(request):
    product_random = random.choice(Product.objects.filter(is_active = True, category__is_active= True))
    product_category= Product.objects.filter(category=product_random.category).exclude(pk=product_random.id)[:4]
    categorys = CategoryProduct.objects.filter(is_active = True)

    context ={
        'title': 'каталог',
        'categorys': categorys,
        'product_random': product_random,
        'product_category': product_category
            }
    return render(request, 'mainapp/products.html', context)


def product(request, pk):
    categorys = CategoryProduct.objects.exclude(is_active = False)
    product = Product.objects.get(id = pk)
    context ={
        'title': 'модель',
        'categorys': categorys,
        'product': product
    }

    return render(request, 'mainapp/product.html', context)


def category(request, pk=None, page=1): 
    if pk == '0':
        product_category=Product.objects.filter(is_active = True, category__is_active = True)
    else:
        product_category = Product.objects.filter(category__pk = pk, is_active =True)
    
    category = CategoryProduct.objects.exclude(is_active = False)
    
    paginator = Paginator(product_category, 4)
    
    try:
        products_paginator = paginator.page(page)
    except PageNotAnInteger:
        products_paginator = paginator.page(1)
    except EmptyPage:
        products_paginator = paginator.page(paginator.num_pages)
    
    context ={
        'title': 'каталог',
        'categorys': category,
        'products': products_paginator
    }

    return render(request, 'mainapp/products_list.html', context)