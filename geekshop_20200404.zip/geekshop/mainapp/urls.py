from django.contrib import admin
from django.urls import path, re_path
import mainapp.views as mainapp

from django.conf import settings
from django.conf.urls.static import static

app_name ='mainapp'

urlpatterns = [
    re_path(r'^$', mainapp.index, name='index'),
    re_path(r'^contact/$', mainapp.contact, name='contact'),
    re_path(r'^products/$', mainapp.products, name='products'),
    re_path(r'^product/(?P<pk>\d+)/$', mainapp.product, name='product'),
    re_path(r'^category/(?P<pk>\d+)/$', mainapp.category, name='category'),
    re_path(r'^category/(?P<pk>\d+)/(?P<page>\d+)/$', mainapp.category, name='page'),
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)