from django.core.management.base import BaseCommand
from mainapp.models import Contacts, CategoryProduct, Product, ScaleProduct, MarkProduct
from mainapp.models import ManufacturerProduct, ProductionProduct, MaterialProduct
from authapp.models import ShopUser

import json, os

JSON_PATH = 'mainapp/json'

def load_from_json(file_name):
    with open(os.path.join(JSON_PATH, file_name + '.json'), 'r') as infile:
        return json.load(infile)

class Command(BaseCommand):

    def handle(self, *args, **options):

        contacts = load_from_json('contacts')
        Contacts.objects.all().delete()
        for contact in contacts:
          new_contact = Contacts(**contact)
          new_contact.save()

        categories = load_from_json('categories')
        CategoryProduct.objects.all().delete()
        for category in categories:
            new_category = CategoryProduct(**category)
            new_category.save()        
               
        scales = load_from_json('scale')
        ScaleProduct.objects.all().delete()
        for scale in scales:
            new_scale = ScaleProduct(**scale)
            new_scale.save()

        marks = load_from_json('mark')
        MarkProduct.objects.all().delete()
        for mark in marks:
            MarkProduct.objects.create(**mark)

        manufacturers = load_from_json('manufacturer')
        ManufacturerProduct.objects.all().delete()
        for manufacturer in manufacturers:
            ManufacturerProduct.objects.create(**manufacturer)

        productions = load_from_json('production')
        ProductionProduct.objects.all().delete()
        for production in productions:
            ProductionProduct.objects.create(**production)

        materials = load_from_json('material')
        MaterialProduct.objects.all().delete()
        for material in materials:
            MaterialProduct.objects.create(**material)


        products = load_from_json('products')
        
        Product.objects.all().delete()
        for product in products:
            category_name = product["category"]
            scale_product = product["scale"]
            mark_product = product["mark"]
            manufacturer_product = product["manufacturer"]
            production_product = product["production"]
            material_product = product["material"]
            # Получаем категорию по имени
            _category = CategoryProduct.objects.get(name=category_name)
            _scale = ScaleProduct.objects.get(name=scale_product)
            _mark = MarkProduct.objects.get(name=mark_product)
            _manufacturer= ManufacturerProduct.objects.get(name=manufacturer_product)
            _production = ProductionProduct.objects.get(name=production_product)
            _material = MaterialProduct.objects.get(name=material_product)

            # Заменяем название категории объектом
            product['category'] = _category
            product["scale"] = _scale
            product["mark"] = _mark
            product["manufacturer"] =_manufacturer
            product["production"]= _production
            product["material"]=_material

            new_product = Product(**product)
            new_product.save()

        # Создаем суперпользователя при помощи менеджера модели
        super_user = ShopUser.objects.create_superuser('django', 'django@geekshop.local', 'geekbrains')