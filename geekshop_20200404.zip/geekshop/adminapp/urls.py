from django.urls import path, re_path
import adminapp.views as adminapp

app_name ='adminapp'

urlpatterns = [
    re_path(r'^user/$', adminapp.UsersListView.as_view(), name='users'),
    re_path(r'^categories/$', adminapp.CategoryListView.as_view(), name='categories'),
    re_path(r'^products/(?P<pk>\d+)/$', adminapp.ProducrsListView.as_view(), name='products'),
    re_path(r'^user_create/$', adminapp.UserCreateView.as_view(), name='user_create'),
    re_path(r'^user_update/(?P<pk>\d+)/$', adminapp.UserUpdateView.as_view(), name='user_update'),
    re_path(r'^user_delete/(?P<pk>\d+)/$', adminapp.UserDeleteView.as_view(), name='user_delete'),
    re_path(r'^category_update/(?P<pk>\d+)/$', adminapp.ProductCategoryUpdateView.as_view(), name='category_update'),
    re_path(r'^category_create/$', adminapp.ProductCategoryCreateView.as_view(), name='category_create'),
    re_path(r'^category_delete/(?P<pk>\d+)/$', adminapp.ProductCategoryDeleteView.as_view(), name='category_delete'),
    re_path(r'^product_read/(?P<pk>\d+)/$', adminapp.ProductDetailView.as_view(),name='product_read'),
    re_path(r'^product_update/(?P<pk>\d+)/$', adminapp.ProductUpdateView.as_view(),name='product_update'),
    re_path(r'^product_create/(?P<pk>\d+)/$', adminapp.ProductCreateView.as_view(),name='product_create'),
    re_path(r'^product_delete/(?P<pk>\d+)/$', adminapp.ProductDeleteView.as_view(),name='product_delete'),
    
]
