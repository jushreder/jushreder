from django.shortcuts import render, get_object_or_404, HttpResponseRedirect
from authapp.models import ShopUser
from mainapp.models import CategoryProduct, Product
from django.contrib.auth.decorators import user_passes_test
from authapp.forms import ShopUserRegisterForm
from adminapp.forms import ShopUserAdminEditForm, CategoryProductEditForm, ProductEditForm
from django.urls import reverse
from django.views.generic.list import ListView
from django.utils.decorators import method_decorator
from django.views.generic.edit import CreateView, UpdateView
from django.urls import reverse_lazy
from django.views.generic.edit import DeleteView
from django.views.generic.detail import DetailView
from django.views.generic import View


class ContextMixin:
    title = ''
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = self.title
        return context


class AdminSuperUserMixin:
    @method_decorator(user_passes_test(lambda u: u.is_superuser))
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)


class AdminObjectDelete:
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        self.object.is_active = False
        self.object.save()       
        return HttpResponseRedirect(self.get_success_url())


class UsersListView(AdminSuperUserMixin, ContextMixin, ListView):
    model = ShopUser
    title = 'админка/пользователи'


class UserCreateView(AdminSuperUserMixin, ContextMixin, CreateView):
    model = ShopUser
    success_url = reverse_lazy('myadmin:users')
    title = 'пользователи/создание'
    form_class =  ShopUserRegisterForm


class UserUpdateView(AdminSuperUserMixin, ContextMixin, UpdateView):
    model = ShopUser
    success_url = reverse_lazy('myadmin:users')
    title = 'пользователи/редактирование'
    form_class =  ShopUserAdminEditForm


class UserDeleteView(AdminSuperUserMixin, ContextMixin, AdminObjectDelete, DeleteView):
    model = ShopUser
    title = 'пользователи/удаление'
    success_url = reverse_lazy('myadmin:users') 
    form_class =  ShopUserRegisterForm


class CategoryListView(AdminSuperUserMixin, ContextMixin, ListView):
    model = CategoryProduct
    title = 'админка/категории'


class ProductCategoryCreateView(AdminSuperUserMixin, ContextMixin, CreateView):
    model = CategoryProduct
    success_url = reverse_lazy('myadmin:categories')
    form_class =  CategoryProductEditForm
    title = 'категории/создание'
   

class ProductCategoryUpdateView(AdminSuperUserMixin, ContextMixin,UpdateView):
    model = CategoryProduct
    success_url = reverse_lazy('myadmin:categories')
    title = 'категории/редактирование'
    form_class =  CategoryProductEditForm


class ProductCategoryDeleteView(AdminSuperUserMixin, ContextMixin, AdminObjectDelete, DeleteView):
    model = CategoryProduct
    success_url = reverse_lazy('myadmin:categories')
    title = 'категории/удаление'
 

class ProducrsListView(AdminSuperUserMixin, ContextMixin, ListView):
    model = Product
    title = 'админка/продукты категории'
    def get_queryset(self):
        self.queryset= super().get_queryset().filter(category=self.kwargs['pk'])
        return self.queryset


class ProductDetailView(AdminSuperUserMixin, ContextMixin, DetailView):
    model = Product
    title = 'продукт/подробнее'


class ProductCreateView(AdminSuperUserMixin, ContextMixin, CreateView):
    model = Product 
    title = 'продукт/создание'
    success_url = reverse_lazy('myadmin:categories')
    # def get_initial(self):
    #     category = get_object_or_404(CategoryProduct, pk=self.object.category.pk)
    #     return {'category': category}
    form_class = ProductEditForm


class ProductUpdateView(AdminSuperUserMixin, ContextMixin, UpdateView):
    model = Product
    title = 'продукт/редактирование'
    form_class = ProductEditForm
    def get_success_url(self):
        return reverse_lazy('myadmin:products', args = [self.object.category.pk])
       

class ProductDeleteView(AdminSuperUserMixin, ContextMixin, AdminObjectDelete, DeleteView):
    model = Product
    # success_url = reverse_lazy('admin:categories')
    title = 'продукт/удаление'
    def get_success_url(self):
        return reverse_lazy('myadmin:products', args = [self.object.category.pk])
    