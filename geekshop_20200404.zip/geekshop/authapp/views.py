from django.shortcuts import render, HttpResponseRedirect
from authapp.forms import ShopUserLoginForm, ShopUserRegisterForm 
from authapp.forms import ShopUserProfileEditForm, ShopUserEditForm
from authapp.models import ShopUser
from django.contrib import auth
from django.urls import reverse
from django.core.mail import send_mail
from geekshop import settings
from django.db import transaction

def login(request):
    title = 'вход'
    
    login_form = ShopUserLoginForm(data=request.POST or None)
    
    next = request.GET['next'] if 'next' in request.GET.keys() else ''
    
      
    if request.method == 'POST':
        form = ShopUserLoginForm(data=request.POST)
        if form.is_valid():
            username = request.POST['username']
            password = request.POST['password']
        
            user = auth.authenticate(username=username, password=password)
            if user and user.is_active:
                auth.login(request, user, 
                backend='django.contrib.auth.backends.ModelBackend')
                if 'next' in request.POST.keys():
                    return HttpResponseRedirect(request.POST['next'])
                else:
                    return HttpResponseRedirect(reverse('mainapp:index'))
    else:
        form = ShopUserLoginForm()

    context = {'title': title,
               'form': form,
               'next': next
               }
    return render(request, 'authapp/login.html',context)


def logout(reguest):
    auth.logout(reguest)
    return HttpResponseRedirect(reverse('main:index')) 
    

def register(request):
    title = 'регистрация'
    
    if request.method == 'POST':
        form = ShopUserRegisterForm(request.POST, request.FILES)
    
        if form.is_valid():
            user = form.save()
            if send_verify_mail(user):
                print('сообщение подтверждения отправлено')
                print(user.username)
                print(user.email)
                context={
                    'username': user.username,
                    'first_name' : user.first_name,
                    'user_email' : user.email,
                    'title' : 'сообщение'
                }
                return render(request,'authapp/message.html', context )
            else:
                print('ошибка отправки сообщения')
                
                
                return HttpResponseRedirect(reverse('main:message'))
    else:
        form = ShopUserRegisterForm()

    context = {'title': title, 'form': form}   
    return render(request, 'authapp/register.html',context)


@transaction.atomic
def edit(request):
    title = 'редактирование'
    
    if request.method == 'POST':
        form = ShopUserEditForm(request.POST, request.FILES, instance=request.user)
        form_profile = ShopUserProfileEditForm(request.POST, request.FILES,
         instance=request.user.shopuserprofile)
        if form.is_valid() and form_profile.is_valid():
            form.save()
            form_profile.save()
            return HttpResponseRedirect(reverse('auth:edit'))
    else:
        form = ShopUserEditForm(instance=request.user)
        form_profile = ShopUserProfileEditForm(instance=request.user.shopuserprofile)
    
    context = {'title': title, 'form': form, 'form_profile': form_profile}
    
    return render(request, 'authapp/edit.html', context)


def send_verify_mail(user):
    verify_link = reverse('auth:verify', kwargs={
        'email' : user.email,
        'activition_key' : user.activition_key
        })
    title = f'Подтверждение учетной записи {user.username}'
    message = f'Для подтверждения учетной записи {user.username}' \
             f'{settings.DOMAIN_NAME} перейдите по ссылке: \n' \
             f'{settings.DOMAIN_NAME}{verify_link}'
    

    return send_mail(title, message, settings.EMAIL_HOST_USER, [user.email], fail_silently=False)


def verify(request, email, activition_key):
    try:
        user = ShopUser.objects.get(email = email)
        if user.activition_key == activition_key and not user.is_activition_key_expires():
            user.is_active = True
            user.save()
            auth.login(request, user,
            backend='django.contrib.auth.backends.ModelBackend')
        else:
            print(f'ошибка верификации пользователя: {user}')
        return render(request, 'authapp/verification.html',{'title':'верификация'})
    except Exception as e:
        print(f'ошибка верификации пользователя: {e.args}')
        return HttpResponseRedirect(reverse('main:index'))

