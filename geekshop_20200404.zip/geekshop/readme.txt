lesson 1
ошибка в названии папки <mainapp/templates/mainapp/> ,было <mainapp/templates.geekshop/>

не добавил в static fonts

re_path(r'^', include('mainapp.urls', namespace='name')) - ошибка!?
не верно указал <app_name ='mainapp'> было <app_mame ='mainapp'>

lesson 2
lesson 3

django2 

1 virtualbox ubuntu
 venv -> django_2
 alias rc='nano ~/.bashrc && source ~/.bashrc'
 alias activate='cd /home/jushreder/django/geekshop && 
        source /home/jushreder/django/django_2/bin/activate'
alias runserver='python /home/jushreder/django/geekshop/
       manage.py runserver'


2 убрал заначения данных карзины в главном меню на странице корзины 

3 поле activition_key_expires не добавлялось в миграцию по 
  причине ошибки def activition_key_expires(),
  исправил  def is_activition_key_expires() все ок

собрал все ошибки какие только есть!
но всетаки активация заработала!
стили пока не стал трогать
еще денек другой надо "покрутить" активацию


"кручу-верчу запутать хочу"
заметил баг: если через админку "удалить" юзера или редактировать его данные, активировать его в админки уже что-то не дает! 
- решено! в классе стояла форма для регистрации

зарегистрировался на сайте  gmail.com -> mail.ru
есть скриншоты

mail.ru просит регистрацию доменного имени!
оставил до развертывания "боевого сервера"
разобрался с EMAIL_HOST_USER = os.environ.setdefault('DJANGO_MAIL_HOST_USER','django@geekshop.local') все работает!


вернулся под  macos( virtualbox - ubuntu работает "но очень сильно тупит", сделать надо на отдельной "банке")

 регистрация через вк - долго и мучительно 
 через гугл по проторенной дороге 

 c pipeline   нужно еще "по крутить"