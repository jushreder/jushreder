from django.urls import path, re_path
import basketapp.views as basketapp


app_name ='basketapp'

urlpatterns = [
    re_path(r'^$', basketapp.index, name='basket'),
    re_path(r'^basket_add/(?P<pk>\d+)$', basketapp.basket_add, name='basket_add'),
    re_path(r'^remove/(?P<pk>\d+)$', basketapp.basket_remove, name='remove'),
    re_path(r'^edit/(?P<pk>\d+)/(?P<quantity>\d+)/$', basketapp.basket_edit, name='edit')

]
